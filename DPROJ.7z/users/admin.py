from django.contrib import admin
#from .models import Profile

# the 'Profile' table is not currently used in this application, but might get utilized later
#admin.site.register(Profile)
